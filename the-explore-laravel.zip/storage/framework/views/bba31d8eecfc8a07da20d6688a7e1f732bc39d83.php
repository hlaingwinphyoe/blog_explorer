<?php $__env->startSection('title'); ?> Edit Post : <?php echo e(env("APP_NAME")); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-8">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4>Edit Post</h4>
                    <p>
                        <i class="fa-regular fa-calendar"></i>
                        <?php echo e(date("j M Y")); ?>

                    </p>
                </div>

                <form action="<?php echo e(route('post.update',$post->id)); ?>" id="gallery-create" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-floating mb-3">
                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" value="<?php echo e(old('title',$post->title)); ?>" placeholder="no need">
                        <label for="floatingInput">Post Title</label>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback ps-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" id="coverPreview" class="cover-img w-100 rounded <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" alt="">
                        <input type="file" name="cover" class="d-none" id="cover" accept="image/jpeg,image/png">
                        <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback ps-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="Leave a comment here" id="floatingTextarea" style="height: 350px"><?php echo e(old('description',$post->description)); ?></textarea>
                        <label for="floatingTextarea">Share Your Experience</label>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback ps-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </form>

                <div class="border rounded p-4 mb-4" id="gallery">
                    <div class="d-flex align-items-stretch overflow-scroll" >
                        <div class="border px-5 me-1 rounded-1 me-1 d-flex justify-content-center align-items-center" id="upload-ui" style="height: 150px">
                            <i class="fa-regular fa-images fa-2xl"></i>
                        </div>
                        <div class="d-flex " style="height: 150px">
                            <?php $__empty_1 = true; $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex align-items-end position-relative me-1">
                                    <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="h-100 rounded-1" alt="">
                                    <form action="<?php echo e(route('gallery.destroy',$gallery->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger btn-sm gallery-del rounded-circle">
                                            <i class="fa-regular fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <form action="<?php echo e(route('gallery.store')); ?>" method="post" id="gallery-upload" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id"  value="<?php echo e($post->id); ?>">
                        <input type="file" name="galleries[]" id="gallery-input" class="d-none <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" multiple>
                        <?php $__errorArgs = ['galleries'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback ps-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['galleries.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback ps-2"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </form>
                </div>
                <div class="text-center mb-5">
                    <button class="btn btn-primary btn-lg" form="gallery-create">
                        <i class="fa-solid fa-edit"></i>
                        Update Post
                    </button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>

        let coverPreview = document.querySelector("#coverPreview");
        let cover = document.querySelector("#cover");

        coverPreview.addEventListener('click',_=>cover.click());

        cover.addEventListener('change',_=>{
            let reader = new FileReader();
            reader.readAsDataURL(cover.files[0]);
            reader.onload = function (){
                coverPreview.src = reader.result;
            }
        })

        let uploadUi = document.querySelector("#upload-ui");
        let galleryInput = document.querySelector("#gallery-input");
        let galleryUpload = document.querySelector("#gallery-upload");

        uploadUi.addEventListener('click',_=> galleryInput.click());

        galleryInput.addEventListener('change',function (){
            galleryUpload.submit();
        })


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel\the-explore-laravel\resources\views/post/edit.blade.php ENDPATH**/ ?>