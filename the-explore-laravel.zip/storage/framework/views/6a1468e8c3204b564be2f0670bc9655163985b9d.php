<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title',env("APP_NAME")); ?></title>
    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>

<nav class="navbar navbar-expand-lg navbar-light bg-white position-fixed top-0 w-100 shadow-sm" style="z-index: 5">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('index')); ?>">
            <img src="<?php echo e(asset('images/logo.png')); ?>" height="50" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <div class="dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(asset(auth()->user()->photo)); ?>" class="user-img rounded-circle shadow-sm border border-2 border-white me-2" alt="">
                            <span class="d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span>
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li><span class="d-block d-md-none"><i class="fa fa-user me-2 text-primary"></i><?php echo e(auth()->user()->name); ?></span></li>
                            <li><a href="<?php echo e(route('edit-profile')); ?>" class="dropdown-item"><i class="fa-solid fa-user-cog me-2 text-success"></i>Edit Profile</a></li>
                            <li><a href="<?php echo e(route('change-password')); ?>" class="dropdown-item"><i class="fa-solid fa-key me-2 text-secondary"></i>Change Password</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fa fa-sign-out-alt me-2 text-danger"></i>Log Out</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="py-5"></div>
<?php echo $__env->yieldContent('content'); ?>

<div class="py-4 bg-primary text-center text-white">
    &copy; <?php echo e(date('Y')); ?> MMS IT, All Rights Reserved.
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH H:\laravel\the-explore-laravel\resources\views/master.blade.php ENDPATH**/ ?>